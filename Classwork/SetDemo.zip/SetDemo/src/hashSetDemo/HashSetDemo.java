package hashSetDemo;

import java.util.HashSet;

public class HashSetDemo {
	public static void main(String[] args) {
		HashSet<String> dogSet = new HashSet<String>();
		dogSet.add("Midge");
		dogSet.add("Zelda");
		dogSet.add("Eve");
		dogSet.add("Carmen");
		dogSet.add("Leonard");
		dogSet.add("Zelda");
		System.out.println("Dog set contains "
				+ dogSet.size() + " elements: "
				+ dogSet);
		System.out.println("Midge is in set: "
				+ dogSet.contains("Midge"));
		System.out.println("Odie is in set: "
				+ dogSet.contains("Odie"));
		dogSet.remove("Midge");
		System.out.println("Dog set contains "
				+ dogSet.size() + " elements: "
				+ dogSet);
		System.out.println("Midge is in set: "
				+ dogSet.contains("Midge"));
	}

}
