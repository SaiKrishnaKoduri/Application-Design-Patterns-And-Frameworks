package setDemo;
import java.util.*;

public class UnionAndIntersectionDemo {
	public static void main(String[] args) {
		TreeSet<Integer> setA = new TreeSet<Integer>();
		TreeSet<Integer> setB = new TreeSet<Integer>();
		TreeSet<Integer> unionSet = new TreeSet<Integer>();
		TreeSet<Integer> intersectSet = new TreeSet<Integer>();

		setA.add(24);
		setA.add(34);
		setA.add(15);
		setA.add(45);

		setB.add(25);
		setB.add(24);
		setB.add(34);
		setB.add(35);

		System.out.println("Elements in Set A: " + setA);
		System.out.println("Elements in Set B: " + setB);

		// Union
		unionSet.addAll(setA);
		unionSet.addAll(setB);
		System.out.println("Elements of Set A union Set B: " + unionSet);

		// Intersection
		for (int a : setA) {
			if (setB.contains(a)) {
				intersectSet.add(a);
			}
		}
		System.out.println("Elements of Set A intersect Set B: " + intersectSet);
	}
}
