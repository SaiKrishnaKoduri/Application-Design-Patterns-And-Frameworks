package setDemo;
import java.util.*;
public class NumberSet {
	public static void main(String[] args) {
		HashSet<Integer> oddSet = new HashSet<Integer>();
		oddSet.add(27);
		oddSet.add(33);
		oddSet.add(13);
		oddSet.add(19);
		oddSet.add(41);
		oddSet.add(55);
		System.out.println("Odd set contains "
				+ oddSet.size() + " elements: "
				+ oddSet);
		System.out.println("27 is in set: "
				+ oddSet.contains(27));
		System.out.println("24 is in set: "
				+ oddSet.contains(24));
		oddSet.remove(27);
		System.out.println("Odd set contains "
				+ oddSet.size() + " elements: "
				+ oddSet);
		System.out.println("27 is in set: "
				+ oddSet.contains(27));
		TreeSet<Integer> evenSet = new TreeSet<Integer>();
		evenSet.add(10);
		evenSet.add(34);
		evenSet.add(22);
		evenSet.add(14);
		evenSet.add(74);
		System.out.println();
		System.out.println(evenSet);
		System.out.println();
		System.out.println("10 is in set: "
				+ evenSet.contains(10));
		System.out.println();
		for (int e : evenSet)
		{
			System.out.println(e);
		}
		System.out.println();
		Iterator<Integer> iter = evenSet.iterator();
		while (iter.hasNext())
		{
			System.out.println(iter.next());
		}
	}

}
