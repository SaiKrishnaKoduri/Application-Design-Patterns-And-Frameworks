package arrayListDemo;
import java.util.*;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList<String> cities = new ArrayList<>();
		cities.add("St. Jo");
		cities.add("St. Louis");
		cities.add("Maryville");
		cities.add("Kansas City");
		cities.add("Santa Clara");
		cities.add("Sacremento");
		System.out.println("Size is: "+cities.size());
		System.out.println();
		//1. Print all the cities using enhanced for loop.
		for(String val : cities) {
			System.out.println(val);
		}
		System.out.println();
		//2. Print all the cities using traditional for loop.
		for(int i=0;i<cities.size()-1;i++) {
			System.out.println(cities.get(i));
		}
		System.out.println();
		//3. Print all the cities that ends with letter 'o'.
		for(String val : cities) {
			if(val.charAt(val.length()-1)=='o' || val.charAt(val.length()-1)=='O') {
				System.out.println(val);
			}
		}
		System.out.println();
		//4. Print all the cities and it's length Ex: St. Jo - 6.
		for(String val : cities) {
			System.out.println(val+"-"+val.length());
		}
		System.out.println();
		//5. Print the city with highest length.
		int max =0;
		ArrayList<String> citiesWithHighestLength = new ArrayList<>();
		for (String city : cities) {
            int cityLength = city.length();
            if (cityLength > max) {
            	max = cityLength;
                citiesWithHighestLength.clear();
                citiesWithHighestLength.add(city);
            } 
            else if (cityLength == max) {
                citiesWithHighestLength.add(city);
            }
        }
		for(String city : citiesWithHighestLength) {
			System.out.println(city);
		}
		System.out.println();
		for(int i=0;i<cities.size();i++) {
			System.out.println(cities.remove(i));
		}
		System.out.println();
		System.out.println(cities);

		}
	}
